Kurulum:
1) Python paketleri: pip install PySide6 selenium requests undetected-chromedriver
2) Windows'ta (UC yoksa) chromedriver.exe'yi klasöre ekleyin (veya drivers/).
3) Çalıştırma: python shorts_main.py
İpucu: İlk girişte Google güvenlik/doğrulama isterse ekranda tamamlayın; profil kalıcıdır.
