# -*- coding: utf-8 -*-
import os, time, re, threading
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options as ChromeOptions
import selenium.webdriver as webdriver

try:
    import undetected_chromedriver as uc
    USE_UC=True
except:
    USE_UC=False

APP_DIR=os.path.dirname(__file__)

class ChromeController:
    def __init__(self,profile_dir=None):
        self.chrome=None; self.profile_dir=profile_dir
    def start(self):
        if USE_UC:
            opts=uc.ChromeOptions()
            if self.profile_dir:
                os.makedirs(self.profile_dir,exist_ok=True)
                opts.add_argument(f"--user-data-dir={self.profile_dir}")
            self.chrome=uc.Chrome(options=opts)
        else:
            opts=ChromeOptions()
            if self.profile_dir:
                os.makedirs(self.profile_dir,exist_ok=True)
                opts.add_argument(f"--user-data-dir={self.profile_dir}")
            self.chrome=webdriver.Chrome(options=opts)
    def stop(self):
        try:
            if self.chrome:self.chrome.quit()
        except: pass
        self.chrome=None

class RotatorWorker(threading.Thread):
    def __init__(self,email,password):
        super().__init__(daemon=True)
        self.email=email; self.password=password
        prof=re.sub(r"[^a-zA-Z0-9_.-]+","_",email or "default")
        self.controller=ChromeController(profile_dir=os.path.join(APP_DIR,"profiles",prof))
    def run(self):
        self.controller.start()
        drv=self.controller.chrome
        drv.get("https://accounts.google.com/")
        time.sleep(2)
        if "signin" in drv.current_url:
            try:
                drv.find_element(By.ID,"identifierId").send_keys(self.email)
                drv.find_element(By.ID,"identifierNext").click()
                WebDriverWait(drv,20).until(lambda d: d.find_element(By.NAME,"Passwd"))
                drv.find_element(By.NAME,"Passwd").send_keys(self.password)
                drv.find_element(By.ID,"passwordNext").click()
            except Exception as e:
                print("Login error",e)
        time.sleep(5)
        self.controller.stop()
