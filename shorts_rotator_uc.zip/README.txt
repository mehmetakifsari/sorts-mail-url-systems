Kurulum: pip install undetected-chromedriver selenium requests
Çalıştır: python shorts_main.py
