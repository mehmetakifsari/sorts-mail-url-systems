Kurulum:
1) zip'i açın, dosyaları aynı klasöre koyun.
2) mail_accounts.json içinde Gmail hesaplarınız hazır (provider: google).
3) Windows'ta Chrome ve uyumlu chromedriver.exe (aynı klasör veya drivers/) gereklidir.
4) Çalıştırma: python shorts_main.py
Not: İlk girişte Google 2FA/CAPTCHA sorarsa ekranda tamamlayın; profil kalıcıdır.
