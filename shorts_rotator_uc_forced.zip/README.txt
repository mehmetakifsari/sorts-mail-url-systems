Gerekli kurulum (bir kez):
  pip install PySide6 selenium requests undetected-chromedriver

Çalıştırma:
  python shorts_main.py

Not: İlk girişte Google güvenlik/challenge ekranı açılırsa pencerede doğrulamayı tamamlayın.
     Profil 'profiles/<email>' altında kalır; sonraki çalıştırmalarda oturum hazır olur.
